﻿namespace MyClassLibrary
{
    public class Class1
    {

    }
}